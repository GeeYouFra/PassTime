package com.example.helloworld.web;


import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.helloworld.domain.Book;
import com.example.helloworld.domain.Friend;
import com.example.helloworld.domain.Message;
import com.example.helloworld.domain.Student;


@Controller
public class HelloController {

	@RequestMapping("/hello")
	public String addHello(@RequestParam(value = "name") String name, Model model,
			@RequestParam(value = "age") Integer age, Model modelB) {
		model.addAttribute("name", name);
		modelB.addAttribute("age", age);
		return "output";
	}

	@RequestMapping("/studentHello")
	public String students(Model model) {
		List<Student> students = new ArrayList<Student>();
		Student student1 = new Student("Giovani", "Francisco");
		Student student2 = new Student("Elon", "Musk");
		Student student3 = new Student("Robert", "Kawasaki");

		students.add(student1);
		students.add(student2);
		students.add(student3);
		model.addAttribute("students", students);
		return "student";
	}

	private List<Friend> friendList = new ArrayList<Friend>();

	@GetMapping("/index")
	public String friends(Model model) {
		model.addAttribute("friend", new Friend());
		model.addAttribute("friendList", friendList);
		return "index";
	}

	@PostMapping("/index")
	public String addFriends(@ModelAttribute Friend friend, Model model) {
		friendList.add(friend);
		System.out.println(friendList);
		return "redirect:/index";
	}

	@RequestMapping("/books")
	public String books(Model model) {
		List<Book> bookstore = new ArrayList<Book>();
		Book bookA = new Book("One Life", "Giovani Francisco", 2021, "ISBN-12344321987789", 19.90);
		bookstore.add(bookA);
		
		model.addAttribute("bookstore", bookstore);
		return "book";
	}
	
	
	
//	@GetMapping("/form")
//	public String formAccess(Model model) {
//		model.addAttribute("message", new Message());
//		return "form";
//	}
//	
//	@GetMapping("/result")
//	public String resultAccess(Model model) {
//		return "result";
//	}
//
//	@PostMapping("/hello")
//	public String greetingSubmit(@ModelAttribute Message msg, Model model) {
//		model.addAttribute("message", msg);
//		return "/result";
//	}
//
//	@RequestMapping("/message")
//	public String messages(Model model) {
//		Message message1 = new Message();
//		message1.setContent("Moon");
//		Message message2 = new Message();
//		message2.setContent("Uranus");
//		Message message3 = new Message();
//		message3.setContent("Mars");
//
//		List<Message> messages = new ArrayList<Message>();
//		messages.add(message1);
//		messages.add(message2);
//		messages.add(message3);
//
//		model.addAttribute("messages", messages);
//		return "messagelist";
//	}
//
//	@RequestMapping("/greeting")
//	public String addHello(@RequestParam(name = "name") String name, Model model) {
//		model.addAttribute("name", name);
//
//		// WE RETURN A FILENAME, NOT A STRING TO SCREEN
//		return "hello";
//	}
}
