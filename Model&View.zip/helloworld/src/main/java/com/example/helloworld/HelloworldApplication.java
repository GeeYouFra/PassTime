package com.example.helloworld;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloworldApplication {

	// MY GITHUB HOMEPAGE: github.com/GeeYouFra
	
	
	public static void main(String[] args) {
		SpringApplication.run(HelloworldApplication.class, args);
	}

}
